//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "cpingth.h"
#include <QtCore>

void CPingTh::run()
{
	int exit_code;
	QHostInfo::lookupHost(ping_ip, this, SLOT(slot_ping_ok(QHostInfo)));
	exec();
}

void CPingTh::slot_make_ping(QString ip)
{
	ping_ip=ip;
}

void CPingTh::slot_ping_ok(QHostInfo host)
{
	if(host.error() != QHostInfo::NoError)
	{
		emit signal_ping_ok(ping_ip, 1);
	}
	else
	{
		emit signal_ping_ok(ping_ip, 0);
	}
}
