//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include <QApplication>
#include "window.h"

int main(int argc, char** argv)
{
	QApplication app(argc, argv);
	
	Window window;
	window.resize(800,600);
	window.setWindowTitle("Lan painter");
	window.setWindowIcon(QPixmap(":/images/icon.png"));
	window.show();
	
	QCoreApplication::setOrganizationName("DonSTU");
	QCoreApplication::setApplicationName("LanPainter");
	
	QApplication::setQuitOnLastWindowClosed(false);
	
	return app.exec();
}
