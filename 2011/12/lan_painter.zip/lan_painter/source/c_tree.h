//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef C_TREE_H
#define C_TREE_H

#include <QWidget>
#define block_width 150
#include "member.h"

class QMenu;
class QTimer;
class QAction;

class Stage: public QObject
{
	Q_OBJECT
	
	QList<Member*> members;
	unsigned char stage_height;
	
public:
	void add_member(Member* mem){members.append(mem);};
	Member* get_member(unsigned int n){return members[n];}
	unsigned int get_n(){return members.count();}
	void del_stages(){members.clear();};
	void set_stage_height(unsigned char sh){stage_height=sh;};
	unsigned char get_stage_height(){return stage_height;};
	void replace(unsigned int, unsigned int);
};

class c_tree: public QWidget
{
	Q_OBJECT
	
	QList<Member*> members;
	QList<Member*> mem_cut;
	QList<Member*> mem_hided;
	QList<Stage*> stages;
	void paint_block(QPainter*, Member*);
	Member* find_member(QString);
	void load_tree();
	void make_stages();
	void place_members();
	void paint_lines(QPainter* p);
	void paint_gr(QPaintDevice*);
	Member* root_mem;
	unsigned int mem_finded;
	QPoint m_pos;
	int tr_x, trx_temp, tr_y, try_temp;
	QMenu* pop_menu;
	unsigned char block_at_cursor(int, int, unsigned int*);
	QString current_file_name;
	unsigned char q_pdf; //paint for pdf flag
	bool q_scanning;
	unsigned char current_stage, current_mem, current_pc;
	QString find_next_to_scan();
	void set_member_on(Member*);
	bool ips_exist();
	QTimer* p_tupdate;
	void members_to_combobox();
	int get_max_x();
	int get_max_y();
	float scale;
	QAction* act_paste;
	void cut_member(Member*);
	QAction* act_cut;
	Member* mem_cutted;
	void hide_members(Member*);
	void show_all_members();
	void recursive_hide(Member*);
	Member* new_root_mem;
	Member* old_root_mem;
	//
	QAction* act_correct_pc;
	QAction* act_correct_sw;
	QAction* act_rename;
	QString str_var, str_olr_ex, str_var_sw, str_info, str_not_finded, str_rename, str_new;
	//
	QString current_language;
	
public:
	unsigned int get_members_count(){return members.count();};
    c_tree(QWidget *parent = 0);
    
protected:
    virtual void paintEvent(QPaintEvent*);
    virtual void mousePressEvent(QMouseEvent*);
	virtual void mouseReleaseEvent(QMouseEvent*);
	virtual void mouseMoveEvent(QMouseEvent*);
	virtual void wheelEvent(QWheelEvent*);
    
signals:
	void signal_ping_start(QString);
	void signal_root_clear();
	void signal_root_add(QString);
	void signal_switchcor_add_item();
	void signal_root_set(QString);
	void signal_changed();
	void signal_add_item(QString, QString, QString, QString, QString);
    
public slots:
	void slot_print_pdf();
	void slot_file_save();
	void slot_file_changed(QString);
	void slot_file_reload();
	void slot_correct_pc();
	void slot_redraw_members();
	void slot_correct_sw();
	void slot_add_switch(Member*, QString);
	void slot_delete_switch(QString);
	void slot_ping_complite(QString, int);
	void slot_start_scan();
	void slot_stop_scan();
	void slot_switch_cut();
	void slot_switch_paste();
	void slot_switch_rename();
	void slot_root_changed(QString);
	void slot_show_all();
	void slot_find_member(QString);
	void slot_retranslate_ui(QString);
	void slot_request(int, bool, QString);
};

#endif
