//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "member.h"

Member::Member(QObject *parent) : QObject(parent)
{
	name="noname";
	block_height=34;
	q_on=false;
	temp_on=false;
	scan_current=0;
	not_founded= new c_pc("not_founded");
}


void Member::set_height()
{
	if(get_n_pcs()>3)
	{
		block_height=22+12*(get_n_pcs()/3);
		if((get_n_pcs()%3)!=0)block_height+=12;
	}
}

void Member::del_pc(QString str)
{
	if(pcs.count()>0)
	{
		for(int i=0; i<pcs.count(); i++)
		if(pcs[i]->get_name()==str)
		{
			delete pcs[i];
			pcs.removeOne(pcs[i]);
			break;	
		}	
	}	
}

void Member::buff_to_screen()
{
	q_on=temp_on;
	temp_on=false;
}

void Member::clear_all()
{
	childrens.clear();
	if(pcs.count()>0)
	{
		for(int i=0; i<pcs.count(); i++)
		{
			delete pcs[i];
		}
		pcs.clear();
	} 
	pos_x=0; 
	pos_y=0; 
	block_height=34; 
	name="noname"; 
	q_on=false;
}

c_pc* Member::get_pc_by_name(QString n)
{
	if(pcs.count()>0)
	for(int i=0; i<pcs.count(); i++)
	{
		if(pcs[i]->get_name()==n)
		return pcs[i];
	}	
	return not_founded;
}

c_pc* Member::add_pc(QString str)
{
	c_pc* pc= new c_pc(str);
	pcs.append(pc);
	return pc;
}
