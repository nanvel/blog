//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef MEMBER_H
#define MEMBER_H

#include <QMap>
#include <QObject>
#include <QPoint>
#include "c_pc.h"

class Member: public QObject
{
	Q_OBJECT
	QList<QString> childrens;
	QList<c_pc*> pcs;
	int pos_x, pos_y;
	QString name;
	unsigned char block_height;
	bool q_on, temp_on;
	unsigned char scan_current;
	c_pc* not_founded;
	
public:
	Member(QObject *parent=0);
	void set_pos(int x, int y){pos_x=x; pos_y=y;};
	QPoint get_pos(){return QPoint(pos_x, pos_y);};
	void add_children(QString str){childrens.append(str);};
	unsigned char get_childrens_count(){return childrens.size();};
	QString get_children(unsigned int n){if(n<=(unsigned int)childrens.size())return childrens[n]; return "";};
	void delete_children(QString str){childrens.removeOne(str);};
	unsigned char get_n_pcs(){return pcs.count();};
	unsigned char get_height(){return block_height;}
	QString get_name(){return name;}
	void set_name(QString str){name=str;};
	c_pc* add_pc(QString str);
	c_pc* get_pc(unsigned char n){return pcs[n];};
	c_pc* get_pc_by_name(QString);
	void set_height();
	void set_height(unsigned int h){block_height=h;};
	void clear_all();
	void del_pc(QString);
	void set_on(){q_on=true;};
	void set_off(){q_on=false;};
	bool is_on(){return q_on;}
	unsigned char get_scan_current(){return scan_current;};
	void set_scan_current(unsigned char c){if(c<=pcs.count())scan_current=c;};
	void set_buf_on(){temp_on=true;};
	void set_buf_off(){temp_on=false;};
	bool get_buf(){return temp_on;};
	void buff_to_screen();
};

#endif
