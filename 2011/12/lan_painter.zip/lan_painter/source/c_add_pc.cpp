//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "c_add_pc.h"
#include <QtGui>
#include "member.h"
#include "c_pc.h"

c_add_pc::c_add_pc(Member* mem, QString lang, QWidget *parent):QDialog(parent)
{
	//i18n
	QTranslator translator;
	translator.load(lang, ":/translations"); 
	qApp->installTranslator(&translator);
	//
	QVBoxLayout* pvbox=new QVBoxLayout;
	peditpc=new QLineEdit;
	peditip=new QLineEdit;
	
	plemac=new QLineEdit();
	pledep=new QLineEdit();
	pleadditional=new QLineEdit();
	
	connect(peditpc, SIGNAL(returnPressed()),this, SLOT(slot_change_record()));
	connect(peditip, SIGNAL(returnPressed()),this, SLOT(slot_change_record()));
	lwg=new QListWidget;
	QListWidgetItem* pitem=0;
	m=mem;
	if(mem->get_n_pcs()>0)
	{
		for(int i=0;i<mem->get_n_pcs();i++)
		{
			pitem=new QListWidgetItem(mem->get_pc(i)->get_name()+" ("+mem->get_pc(i)->get_ip()+")", lwg);
		}
		peditpc->setText(mem->get_pc(0)->get_name());
		pledep->setText(mem->get_pc(0)->get_dep());
		peditip->setText(mem->get_pc(0)->get_ip());
		plemac->setText(mem->get_pc(0)->get_mac());
		pleadditional->setText(mem->get_pc(0)->get_additional());
	}
	
	QLabel* pnlabel=new QLabel(tr("<html><table width=\"100%\"><tr><td><hr></td><td>Switch name = ")+ mem->get_name().mid(1,mem->get_name().length()-1)+"</td></tr></table></html>");
	pvbox->addWidget(pnlabel);
	
	pvbox->addWidget(lwg);
	
	QLabel* plblpc=new QLabel(tr("Name:"));
	QLabel* plblip=new QLabel(tr("ip:"));
	
	QGridLayout* pbox=new QGridLayout;
	pbox->addWidget(plblpc, 0,0,1,1);
	pbox->addWidget(peditpc, 0,1,1,1);
	pbox->addWidget(plblip, 0,2,1,1);
	pbox->addWidget(peditip, 0,3,1,1);
	
	//information about mac, department and other entering
	QLabel* plblmac=new QLabel(tr("MAC:"));
	QLabel* plbldep=new QLabel(tr("Dep:"));
	QLabel* plbladditional= new QLabel(tr("Additional:"));
	
	pbox->addWidget(plbldep, 1,0,1,1);
	pbox->addWidget(pledep, 1,1,1,1);
	pbox->addWidget(plblmac, 1,2,1,1);
	pbox->addWidget(plemac, 1,3,1,1);
	pbox->addWidget(plbladditional, 2,0,1,1);
	pbox->addWidget(pleadditional, 2,1,1,3);
	
	pbox->setMargin(2);
	
	
	pvbox->addLayout(pbox);
	pvbox->setMargin(5);
	
	
	QHBoxLayout* phboxcmd=new QHBoxLayout;
	QPushButton* pcmddel=new QPushButton(tr("Delete"));
	connect(pcmddel, SIGNAL(clicked()),this, SLOT(slot_delete_record()));
	QPushButton* pcmdadd=new QPushButton(tr("Add"));
	connect(pcmdadd, SIGNAL(clicked()),this, SLOT(slot_change_record()));
	QPushButton* pcmdexit=new QPushButton(tr("Exit"));
	connect(pcmdexit,SIGNAL(clicked()),this,SLOT(close()));
	phboxcmd->addWidget(pcmdexit);
	phboxcmd->addStretch();
	phboxcmd->addWidget(pcmddel);
	phboxcmd->setMargin(2);
    phboxcmd->addWidget(pcmdadd);
    pvbox->addLayout(phboxcmd);
    
    connect(lwg,SIGNAL(itemClicked(QListWidgetItem*)),this, SLOT(slot_item_clicked(QListWidgetItem*)));
    
	setLayout(pvbox);
	
	setTabOrder(peditpc, peditip);
	setTabOrder(peditip, pcmdadd);
	setTabOrder(pcmdadd, pcmddel);
	setTabOrder(pcmddel,pcmdexit);
	
	peditpc->setFocus();
	
	setWindowTitle(tr("Edit pcs"));
}

void c_add_pc::slot_item_clicked(QListWidgetItem* item)
{
	c_pc* pc;
	QString str;
	str=item->text().split(" ")[0];
	peditpc->setText(str);
	pc=m->get_pc_by_name(str);
	peditip->setText(pc->get_ip());
	pledep->setText(pc->get_dep());
	plemac->setText(pc->get_mac());
	pleadditional->setText(pc->get_additional());
}

void c_add_pc::slot_delete_record()
{
	QList<QListWidgetItem*> lst;
	lst= lwg->findItems(peditpc->text()+" ("+peditip->text()+")", Qt::MatchExactly);
	if(!(lst.isEmpty()))
	{
		delete lst[0];
		m->del_pc(peditpc->text());
		emit signal_redraw_members();
	}
}
	
void c_add_pc::slot_change_record()
{
	QList<QListWidgetItem*> lst;
	QListWidgetItem* temp_item;
	QString name, ip, mac;
	name=peditpc->text();
	while(name.indexOf(" ")!=-1)
	{
		name.replace(name.indexOf(" "), 1, "_");	
	}
	peditpc->setText(name);
	lst= lwg->findItems(name, Qt::MatchStartsWith);
	if(!(lst.isEmpty()))
	{
		delete lst[0];
		m->del_pc(name);
	}
	
	c_pc* pc= m->add_pc(name);
	
	ip=peditip->text();
	while(ip.indexOf(" ")!=-1)
	{
		ip.replace(ip.indexOf(" "), 1, ".");	
	}
	while(ip.indexOf(":")!=-1)
	{
		ip.replace(ip.indexOf(":"), 1, ".");	
	}
	while(ip.indexOf("-")!=-1)
	{
		ip.replace(ip.indexOf("-"), 1, ".");	
	}
	while(ip.indexOf(",")!=-1)
	{
		ip.replace(ip.indexOf(","), 1, ".");	
	}
	peditip->setText(ip);
	QRegExp reg("^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$");
	if(reg.indexIn(ip)==0)
	{
		pc->set_ip(ip);
		temp_item=new QListWidgetItem(name+" ("+ip+")", lwg);
	}
	else
	{
		pc->set_ip("");
		temp_item=new QListWidgetItem(name+" ()", lwg);
	}
	
	//testing emtered mac
	mac=plemac->text();
	while(mac.indexOf(" ")!=-1)
	{
		mac.replace(mac.indexOf(" "), 1, ":");	
	}
	while(mac.indexOf(".")!=-1)
	{
		mac.replace(mac.indexOf("."), 1, ":");	
	}
	while(mac.indexOf(",")!=-1)
	{
		mac.replace(mac.indexOf(","), 1, ":");	
	}
	reg.setPattern("^[0-9,A-F,a-f]{2}:[0-9,A-F,a-f]{2}:[0-9,A-F,a-f]{2}:[0-9,A-F,a-f]{2}:[0-9,A-F,a-f]{2}:[0-9,A-F,a-f]{2}$");
	if(reg.indexIn(mac)!=0)
	mac="";
	plemac->setText(mac);
	
	//addinf info: department, mac, additional
	pc->set_dep(pledep->text());
	pc->set_mac(mac);
	pc->set_additional(pleadditional->text());
	
	emit signal_redraw_members();
	peditpc->setFocus();
}
