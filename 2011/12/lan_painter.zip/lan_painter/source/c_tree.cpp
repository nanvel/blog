//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "c_tree.h"
#include <QtGui>
#include "c_add_pc.h"
#include "c_add_sw.h"

c_tree::c_tree(QWidget *parent) :  QWidget(parent)
{
	root_mem=new Member;
	root_mem->set_name("root");
	tr_x=10;
	tr_y=5;
	pop_menu=new QMenu;
	act_correct_pc=new QAction(QIcon(":/images/computer_edit.png"),tr("Correct pcs"),this);
	act_correct_pc->setIconVisibleInMenu(true);
	connect(act_correct_pc, SIGNAL(triggered()),this, SLOT(slot_correct_pc()));
	act_correct_sw=new QAction(QIcon(":/images/switch_edit.png"), tr("Correct switches"),this);
	act_correct_sw->setIconVisibleInMenu(true);
	connect(act_correct_sw, SIGNAL(triggered()),this, SLOT(slot_correct_sw()));
	act_cut= new QAction(QIcon(":/images/cut.png"), tr("Cut"), this);
	act_cut->setIconVisibleInMenu(true);
	connect(act_cut, SIGNAL(triggered()), this, SLOT(slot_switch_cut()));
	act_paste= new QAction(QIcon(":/images/paste.png"), tr("Paste"), this);
	act_paste->setIconVisibleInMenu(true);
	connect(act_paste, SIGNAL(triggered()), this, SLOT(slot_switch_paste()));
	act_paste->setEnabled(false);
	act_rename= new QAction(QIcon(":/images/pencil.png"), tr("Rename"), this);
	act_rename->setIconVisibleInMenu(true);
	connect(act_rename, SIGNAL(triggered()), this, SLOT(slot_switch_rename()));
	
	pop_menu->addAction(act_correct_pc);
	pop_menu->addAction(act_correct_sw);
	pop_menu->addSeparator();
	pop_menu->addAction(act_rename);
	pop_menu->addSeparator();
	pop_menu->addAction(act_cut);
	pop_menu->addAction(act_paste);
	
	
	p_tupdate=new QTimer;
	connect(p_tupdate, SIGNAL(timeout()), this, SLOT(repaint()));
	
	q_pdf=0;
	q_scanning=false;
	current_stage=0;
	current_mem=0;
	current_pc=0;
	scale=1;
	
	str_var=tr("Warning");
	str_olr_ex=tr("This name is already exist!");
	str_var_sw=tr("This switch is olready exist!");
	str_info=tr("Information");
	str_not_finded=tr("This name was not finded!");
	str_rename=tr("Rename switch ");
	str_new=tr("New name:");
}

void c_tree::paint_lines(QPainter* p)
{
	QPen pen;
	pen.setColor(QColor(0,0,0));
	pen.setWidth(1);
	p->setPen(pen);
	if(stages.count()>0)
	{//upper_lines
		for(int i=1;i<stages.count();i++)
		{
			for(unsigned int j=0;j<stages[i]->get_n();j++)
			{
				p->drawLine(stages[i]->get_member(j)->get_pos()+QPoint(block_width/2,-15)+QPoint(tr_x,tr_y),stages[i]->get_member(j)->get_pos()+QPoint(block_width/2,0)+QPoint(tr_x,tr_y));
			}
		}
	}
	for(int i=0;i<stages.count();i++)
	{
		for(unsigned int j=0;j<stages[i]->get_n();j++)
		{
			if(stages[i]->get_member(j)->get_childrens_count()>0)
			{
				unsigned int max_x=0;
				for(unsigned int z=0; z<stages[i]->get_member(j)->get_childrens_count();z++)
				{
					if(find_member(stages[i]->get_member(j)->get_children(z))->get_pos().x()>max_x)
					{
						max_x=find_member(stages[i]->get_member(j)->get_children(z))->get_pos().x();
					}
				}
				p->drawLine(stages[i]->get_member(j)->get_pos()+QPoint(block_width/2,stages[i]->get_stage_height())+QPoint(tr_x,tr_y),stages[i]->get_member(j)->get_pos()+QPoint(block_width/2,stages[i]->get_stage_height()+15)+QPoint(tr_x,tr_y));
				p->drawLine(stages[i]->get_member(j)->get_pos()+QPoint(block_width/2,stages[i]->get_stage_height()+15)+QPoint(tr_x,tr_y),QPoint(max_x+block_width/2,stages[i]->get_member(j)->get_pos().y()+stages[i]->get_stage_height()+15)+QPoint(tr_x,tr_y));
			}
		}
	}
	pen.setWidth(1);
	p->setPen(pen);
}

void c_tree::paint_block(QPainter* p, Member* m)
{
	QString str;
	if(q_pdf)
	{
		p->fillRect(QRect(m->get_pos()+QPoint(tr_x,tr_y),m->get_pos()+QPoint(block_width,m->get_height())+QPoint(tr_x,tr_y)),QColor(240,240,240));
	}
	else
	if(m->is_on())
	{
		p->fillRect(QRect(m->get_pos()+QPoint(tr_x,tr_y),m->get_pos()+QPoint(block_width,m->get_height())+QPoint(tr_x,tr_y)),QBrush(QColor(120,200,80)));
	}
	else
	{
		p->fillRect(QRect(m->get_pos()+QPoint(tr_x,tr_y),m->get_pos()+QPoint(block_width,m->get_height())+QPoint(tr_x,tr_y)),QBrush(QColor(210,100,80))); //QBrush(QPixmap(":/images/brush.png"))	
	}
	
	p->setPen(QColor(0,0,0));
	p->drawRect(m->get_pos().x()+tr_x, m->get_pos().y()+tr_y,block_width,m->get_height());
	p->setFont(QFont("Arial", 10));
	p->drawText(QRect(m->get_pos()+QPoint(1,0)+QPoint(tr_x,tr_y),m->get_pos()+QPoint(150,m->get_height())+QPoint(tr_x,tr_y)), Qt::AlignTop|Qt::AlignHCenter, m->get_name().mid(1,m->get_name().length()-1));
	for(unsigned char i=0;i<m->get_n_pcs()/3+1;i++)
	{
		str="";
		for(unsigned char j=0;j<3;j++)
		{
			if((i*3+j)<m->get_n_pcs())
			str+=m->get_pc(i*3+j)->get_name()+" ";	
		}
		p->drawText(QRect(m->get_pos()+QPoint(2,17+12*i)+QPoint(tr_x,tr_y),m->get_pos()+QPoint(block_width,m->get_height())+QPoint(tr_x,tr_y)), Qt::AlignTop|Qt::AlignLeft, str);
	}
	p->setPen(QColor(100,100,100));
	p->drawLine(m->get_pos()+QPoint(1,16)+QPoint(tr_x,tr_y),m->get_pos()+QPoint(block_width-1,16)+QPoint(tr_x,tr_y));
}

void c_tree::make_stages()
{
	unsigned int curr_stage=0;
	unsigned char q;
	stages.append(new Stage);
	stages[0]->set_stage_height(34);
	stages[0]->add_member(root_mem);
	root_mem->set_height();
	if(stages[curr_stage]->get_stage_height()<(root_mem->get_height()))
	stages[curr_stage]->set_stage_height(root_mem->get_height());
	curr_stage++;
	while(1)
	{
		stages.append(new Stage);
		stages[curr_stage]->set_stage_height(34);
		for(unsigned int i=0;i<stages[curr_stage-1]->get_n();i++)
		{
			for(int j=0; j<stages[curr_stage-1]->get_member(i)->get_childrens_count();j++)
			{
				stages[curr_stage]->add_member(find_member(stages[curr_stage-1]->get_member(i)->get_children(j)));
				find_member(stages[curr_stage-1]->get_member(i)->get_children(j))->set_height();
				if(stages[curr_stage]->get_stage_height()<(find_member(stages[curr_stage-1]->get_member(i)->get_children(j))->get_height()))
				stages[curr_stage]->set_stage_height(find_member(stages[curr_stage-1]->get_member(i)->get_children(j))->get_height());
			}		
		}
		while(1)
		{
			q=1;
			if(stages[curr_stage]->get_n()>0)
			{
				for(unsigned int j=1;j < stages[curr_stage]->get_n(); j++)
				{
					if(stages[curr_stage]->get_member(j)->parent()==stages[curr_stage]->get_member(j-1)->parent())
					if(stages[curr_stage]->get_member(j)->get_childrens_count()>stages[curr_stage]->get_member(j-1)->get_childrens_count())
					{
						stages[curr_stage]->replace(j-1,j);
						q=0;
					}
				}
			}
			if(q)break;
		}
		if(stages[curr_stage]->get_n()==0)break;
		curr_stage++;
	}
	members_to_combobox();
}

void c_tree::place_members()
{
	unsigned int pos_y=15;
	unsigned char q, qq;
	for(int i=0; i<stages.count();i++)
	{
		for(unsigned int j=0;j < stages[i]->get_n(); j++)
		{
			stages[i]->get_member(j)->set_pos(j*(block_width+15)+15,pos_y);
			stages[i]->get_member(j)->set_height(stages[i]->get_stage_height());
		}
		pos_y+=stages[i]->get_stage_height()+30;
	}
	while(1)
	{
		qq=1;
		while(1)
		{
			q=1;
			for(unsigned int i=stages.count()-1;i>0;i--)
			{
				for(unsigned int j=0;j<stages[i]->get_n();j++)
				if(stages[i]->get_member(j)->get_pos().x()<(qobject_cast<Member*>(stages[i]->get_member(j)->parent())->get_pos().x()))
				{
					q=0;
					qq=0;
					for(unsigned int z=j;z<stages[i]->get_n();z++)
					{
						stages[i]->get_member(z)->set_pos(stages[i]->get_member(z)->get_pos().x()+block_width+15,stages[i]->get_member(z)->get_pos().y());
						if(z<(stages[i]->get_n()-1))
						{
							if(stages[i]->get_member(z)->get_pos()!=stages[i]->get_member(z+1)->get_pos())break;	
						}
					}	
				}
			}
			if(q)break;
		}
		while(1)
		{
			q=1;
			for(int i=0;i<stages.count()-1;i++)
			{
				for(unsigned int j=0;j<stages[i]->get_n();j++)
				if(stages[i]->get_member(j)->get_childrens_count()>0)
				{ //finding min child
					unsigned int min_pos=50000;
					for(unsigned int z=0;z<stages[i]->get_member(j)->get_childrens_count();z++)
					{
						if(find_member(stages[i]->get_member(j)->get_children(z))->get_pos().x()<min_pos)min_pos=find_member(stages[i]->get_member(j)->get_children(z))->get_pos().x();
					}
					if(min_pos>stages[i]->get_member(j)->get_pos().x())
					for(unsigned int z=j;z<stages[i]->get_n();z++)
					{
						stages[i]->get_member(z)->set_pos(stages[i]->get_member(z)->get_pos().x()+block_width+15,stages[i]->get_member(z)->get_pos().y());
						q=0;
						qq=0;
						if(z<(stages[i]->get_n()-1))
						{
							if(stages[i]->get_member(z)->get_pos()!=stages[i]->get_member(z+1)->get_pos())break;	
						}
					}		
				}
			}
			if(q)break;	
		}
		if(qq)break;
	}
}

void c_tree::paint_gr(QPaintDevice* pd)
{
	QPainter painter(pd);
	
	if(q_pdf)
	painter.fillRect(0,0,pd->width()-1,pd->height()-1,QColor(255,255,255));else
	painter.fillRect(0,0,pd->width()-1,pd->height()-1,QColor(227,227,227));
	
	if(!q_pdf)
	{
		painter.save();
		painter.scale(scale, scale);
	}
	
	if(!members.empty())
	{
		paint_lines(&painter);
		for(int i=0;i<members.count();i++)
		{
			paint_block(&painter,members[i]);
		}
	}
	painter.setPen(QColor(0,0,0));
	
	if(!q_pdf)painter.restore();
	
	//paint greed
	//lines x
	painter.setPen(QColor(255,255,255));
	painter.fillRect(1, 1, pd->width()-2, 10, QColor(227,227,227));
	int nx=get_max_x()/(block_width+15);
	painter.setFont(QFont("Arial", 8));
	for(int i=0; i<nx ;i++)
	{
		if(i%2==0)
		painter.fillRect(i*(block_width+15)+7+tr_x, 1, block_width+15, 10, QColor(50,50,50));
		else
		painter.fillRect(i*(block_width+15)+7+tr_x, 1, block_width+15, 10, QColor(150,150,150));
		painter.drawText(i*(block_width+15)+block_width/2+15+tr_x, 10, QString::number(i));	
	}
	
	//lines y
	painter.fillRect(1, 1, 14, pd->height()-2, QColor(227,227,227));
	Member* last;
	int last_posy, last_n=-1;
	if(stages.count()>0)
	{
		for(int i=0; i<stages.count(); i++)
		if(stages[i]->get_n()>0)
		{
			last=stages[i]->get_member(0);
			//fill
			if(i%2==0)
			painter.fillRect(1, last->get_pos().y()-15+tr_y, 14, last->get_height()+30, QColor(50,50,50));else
			painter.fillRect(1, last->get_pos().y()-15+tr_y, 14, last->get_height()+30, QColor(150,150,150));
			if(i!=0)
			{
				painter.drawText(2, (last_posy+last->get_pos().y()-15+tr_y)/2+4, QString::number(i-1));
				last_n=i-1;
			}
			last_posy=last->get_pos().y()-15+tr_y;
		}	
		painter.drawText(2, (last_posy+last->get_pos().y()+15+tr_y+ last->get_height())/2+4, QString::number(last_n+1));
	}
	painter.setPen(QColor(0,0,0));
        if(!q_pdf)painter.drawRect(0,0,pd->width()-1,pd->height()-1);
	painter.fillRect(1,1,15,11,QColor(227,227,227));
}

void c_tree::paintEvent(QPaintEvent *event)
{
	paint_gr(this);
}

Member* c_tree::find_member(QString str)
{
	for(int i=0;i<members.size();i++)
	if(members[i]->get_name()==str)return members[i];
	root_mem->set_name(str);
	return root_mem;
}

void c_tree::load_tree()
{
	QString str;
	QFile file(current_file_name);
    if(file.open(QIODevice::ReadOnly))
    {
		mem_hided.clear();
		mem_cut.clear();
		Member* parent_mem;
	    Member* temp_mem;
        QTextStream stream(&file);
        while(!stream.atEnd())
        {
			str=stream.readLine();
			if(str=="---IPs---")break;
            QStringList list = str.split(" ", QString::SkipEmptyParts);
            if(list.size()>0)
            {
	            for (int i = 0; i < list.size(); i++)
	            {
	                if(i==0)
	                {
						parent_mem=find_member(list.at(i));
	                }
	                else
	                {
						if(list.at(i)[0]=='+')
						{
							parent_mem->add_children(list.at(i));
							temp_mem=new Member(parent_mem);
							temp_mem->set_name(list.at(i));
							members.append(temp_mem);
						}
						else
						{
							parent_mem->add_pc(list.at(i));
						}
	                }
	            }
			}
        }
        //reading IP adresses
        while(!stream.atEnd())
        {
			str=stream.readLine();
			if(str=="---MACs---")break;
            QStringList list = str.split(" ", QString::SkipEmptyParts);
            if(list.size()==3)
            {
				find_member(list[0])->get_pc_by_name(list[1])->set_ip(list[2]);
			}
        }
        //reading MACs
        while(!stream.atEnd())
        {
			str=stream.readLine();
			if(str=="---DEPs---")break;
            QStringList list = str.split(" ", QString::SkipEmptyParts);
            if(list.size()==3)
            {
				find_member(list[0])->get_pc_by_name(list[1])->set_mac(list[2]);
			}
        }
        //reading departments
        while(!stream.atEnd())
        {
			str=stream.readLine();
			if(str=="---ADDs---")break;
            QStringList list = str.split(" ", QString::SkipEmptyParts);
            if(list.size()>=3)
            {
				find_member(list[0])->get_pc_by_name(list[1])->set_dep(str.mid(list[0].length()+list[1].length()+2,str.length()-list[0].length()-list[1].length()-1));
			}
        }
        //reading additional information
        while(!stream.atEnd())
        {
			str=stream.readLine();
            QStringList list = str.split(" ", QString::SkipEmptyParts);
            if(list.size()>=3)
            {
				find_member(list[0])->get_pc_by_name(list[1])->set_additional(str.mid(list[0].length()+list[1].length()+2,str.length()-list[0].length()-list[1].length()-1));
			}
        }
        file.close();
        members.append(root_mem);
    }
    else
    {
		members.append(find_member("+root"));		
	}
}

void Stage::replace(unsigned int p1, unsigned int p2)
{
	Member* temp;
	temp=members[p1];
	members[p1]=members[p2];
	members[p2]=temp;
}

void c_tree::slot_print_pdf()
{
    QString fname;
    int mx,my;
    mx=0;
    my=0;
    for(int i=0;i<members.count();i++)
    {
		if((members[i]->get_pos().x()+block_width)>mx)mx=members[i]->get_pos().x()+block_width;
		if((members[i]->get_pos().y()+members[i]->get_height())>my)my=members[i]->get_pos().y()+members[i]->get_height();
	}
	
	QFileDialog fileDialog;
    fileDialog.setDefaultSuffix("pdf");
    fileDialog.setAcceptMode(QFileDialog::AcceptSave);
    fileDialog.setConfirmOverwrite(true);
    fileDialog.setDirectory(".");
    fileDialog.setFileMode(QFileDialog::AnyFile);
    fileDialog.setFilter("pdf-files *.pdf");
    fname="";
    if(fileDialog.exec())
    {
        fname=fileDialog.selectedFiles().at(0);
    }	
    if(fname!="")
    {
        QPrinter printer;
        printer.setPaperSize(QSizeF(mx+35,my+35),QPrinter::DevicePixel);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setOutputFileName(fname);
        printer.setCreator("Lan Painter");
        printer.setDocName("Lan");
        printer.setPageMargins(10,10,10,10,QPrinter::DevicePixel);
        trx_temp=tr_x;
        try_temp=tr_y;
        tr_x=10;
        tr_y=5;
        q_pdf=1;
        paint_gr(&printer);
        q_pdf=0;
        tr_x=trx_temp;
        tr_y=try_temp;
    }
};

void c_tree::mousePressEvent(QMouseEvent* pe){
    if(pe->button() == Qt::LeftButton){
        m_pos=pe->pos();
        trx_temp=tr_x;
        try_temp=tr_y;
        setCursor(Qt::ClosedHandCursor);
    };
    if(pe->button() == Qt::RightButton)
    {
		if(block_at_cursor(pe->pos().x(),pe->pos().y(),&mem_finded))
		{
			if(members[mem_finded]!=root_mem)act_cut->setEnabled(true);
			else act_cut->setEnabled(false);
			pop_menu->exec(pe->globalPos());
		};
	}
    QWidget::mousePressEvent(pe);
}

void c_tree::mouseReleaseEvent(QMouseEvent* pe){
    if(pe->button() == Qt::LeftButton){
        setCursor(Qt::OpenHandCursor);
    }
    QWidget::mouseReleaseEvent(pe);
};
	
void c_tree::mouseMoveEvent(QMouseEvent* pe){
    if(pe->buttons() & Qt::LeftButton){
        tr_x=trx_temp+(pe->x() - m_pos.x());
        tr_y=try_temp+(pe->y() - m_pos.y());
        if(tr_x>width()-20)tr_x=width()-20;
        if(tr_y>height()-20)tr_y=height()-20;
        if(tr_x<(-1)*(get_max_x()-20))tr_x=(-1)*(get_max_x()-20);
        if(tr_y<(-1)*(get_max_y()-15))tr_y=(-1)*(get_max_y()-15);
        
        repaint();
    }
    QWidget::mouseMoveEvent(pe);
}

unsigned char c_tree::block_at_cursor(int x, int y, unsigned int* mem_at)
{	
	for(int i=0;i<members.count();i++)
	{
		if((members[i]->get_pos().x()+tr_x<=x)&&(members[i]->get_pos().x()+tr_x+block_width>=x)&&(members[i]->get_pos().y()+tr_y<=y)&&(members[i]->get_pos().y()+members[i]->get_height()+tr_y>=y))
		{
			*mem_at=i;
			//mem_at->set_name(members[i]->get_name());
			return 1;
		}
	}
	return 0;
}

void c_tree::slot_file_save()
{
	bool q_hided=false;
	if(members.count()>0)
	{
		QFile file(current_file_name);
        if(file.open(QIODevice::WriteOnly))
        {
            QTextStream stream(&file);
            //if hided  members existed
            if(mem_hided.count()>0)
            {
				show_all_members();
				q_hided=true;			
			}
            //
            if(members.count()>0)
            {
				stream << root_mem->get_name() << " ";
				if(root_mem->get_childrens_count()!=0)
				for(int j=0; j<root_mem->get_childrens_count();j++)
				{
					stream << root_mem->get_children(j) << " ";
				}
				if(root_mem->get_n_pcs()!=0)
				for(int j=0; j<root_mem->get_n_pcs();j++)
				{
					stream << root_mem->get_pc(j)->get_name() << " ";
				}
				stream << "\n";
	            for(int i=0; i<members.count();i++)
	            {
					if(members[i]!=root_mem)
					if((members[i]->get_childrens_count()!=0)||(members[i]->get_n_pcs()!=0))
					{
						stream << members[i]->get_name() << " ";	
						if(members[i]->get_childrens_count()!=0)
						for(int j=0; j<members[i]->get_childrens_count();j++)
						{
							stream << members[i]->get_children(j) << " ";
						}
						if(members[i]->get_n_pcs()!=0)
						for(int j=0; j<members[i]->get_n_pcs();j++)
						{
							stream << members[i]->get_pc(j)->get_name() << " ";
						}
						stream << "\n";
					}
				}
				//writing IPs
				stream << "---IPs---\n";
				for(int i=0; i<members.count(); i++)
				{
					if(members[i]->get_n_pcs()>0)
					{
						for(int j=0;j<members[i]->get_n_pcs();j++)
						{
							stream << members[i]->get_name() << " " << members[i]->get_pc(j)->get_name() << " " << members[i]->get_pc(j)->get_ip();
							stream<< "\n";
						}
					}
				}
				//writing MACs
				stream << "---MACs---\n";
				for(int i=0; i<members.count(); i++)
				{
					if(members[i]->get_n_pcs()>0)
					{
						for(int j=0;j<members[i]->get_n_pcs();j++)
						{
							stream << members[i]->get_name() << " " << members[i]->get_pc(j)->get_name() << " " << members[i]->get_pc(j)->get_mac();
							stream<< "\n";
						}
					}
				}
				//writing departments
				stream << "---DEPs---\n";
				for(int i=0; i<members.count(); i++)
				{
					if(members[i]->get_n_pcs()>0)
					{
						for(int j=0;j<members[i]->get_n_pcs();j++)
						{
							stream << members[i]->get_name() << " " << members[i]->get_pc(j)->get_name() << " " << members[i]->get_pc(j)->get_dep();
							stream<< "\n";
						}
					}
				}
				//writing additional information
				stream << "---ADDs---\n";
				for(int i=0; i<members.count(); i++)
				{
					if(members[i]->get_n_pcs()>0)
					{
						for(int j=0;j<members[i]->get_n_pcs();j++)
						{
							stream << members[i]->get_name() << " " << members[i]->get_pc(j)->get_name() << " " << members[i]->get_pc(j)->get_additional();
							if((j<members[i]->get_n_pcs()-1)||(i<members.count()-1)) stream<< "\n";
						}
					}
				}
			}
            file.close();
        }
	}
	if(q_hided)
	{
		hide_members(new_root_mem);	
	}
}

void c_tree::slot_file_changed(QString str)
{
	current_file_name=str;
}

void c_tree::slot_file_reload()
{
	root_mem->set_name("root");
	tr_x=10;
	tr_y=5;
	q_pdf=0;
	root_mem->clear_all();
	members.clear();
	stages.clear();
	load_tree();
	make_stages();
	place_members();
	repaint();
}

void c_tree::slot_correct_pc()
{
	c_add_pc add_dialog(members[mem_finded], current_language, this);
	connect(&add_dialog, SIGNAL(signal_redraw_members()), this, SIGNAL(signal_changed()));
	connect(&add_dialog, SIGNAL(signal_redraw_members()),this, SLOT(slot_redraw_members()));
	add_dialog.exec();	
}

void c_tree::slot_correct_sw()
{
	c_add_sw add_switch(members[mem_finded], current_language, this);
	connect(&add_switch,SIGNAL(signal_add_switch(Member*, QString)),this,SLOT(slot_add_switch(Member*, QString)));
	connect(&add_switch,SIGNAL(signal_delete_switch(QString)),this,SLOT(slot_delete_switch(QString)));
	connect(&add_switch,SIGNAL(signal_rebuilt_tree()), this, SLOT(slot_redraw_members()));
	connect(&add_switch,SIGNAL(signal_rebuilt_tree()), this, SIGNAL(signal_changed()));
	connect(this, SIGNAL(signal_switchcor_add_item()), &add_switch, SLOT(slot_add_item()));
	add_switch.exec();	
}

void c_tree::slot_redraw_members()
{
	stages.clear();
	root_mem->set_height(34);
	for(int i=0;i<members.count();i++)members[i]->set_height(34);
	make_stages();
	place_members();
	repaint();
}

void c_tree::slot_add_switch(Member* m, QString str)
{
	bool exist=false;
	if(members.count()>0)
	{
		for(int i=0; i<members.count(); i++)
		{
			if(members[i]->get_name()==str)
			{
				exist=true;
				break;	
			}
		}
	}
	if(!exist)
	{
		Member* temp_mem=new Member(m);
		members.append(temp_mem);
		temp_mem->set_name(str);
		m->add_children(str);
		emit signal_switchcor_add_item();
	}else
	{
		QMessageBox::warning(0, str_var, str_var_sw, QMessageBox::Ok, QMessageBox::Ok);	
	}
}

void c_tree::slot_delete_switch(QString str)
{
	Member* m= find_member(str);
	if(m->get_childrens_count()>0)
	{
		for(int i=0;i<m->get_childrens_count();i++)
		{
			slot_delete_switch(m->get_children(i));	
		}	
	}
	members.removeOne(m);
}

void c_tree::slot_ping_complite(QString ip, int res)
{
	if(res==0)set_member_on(stages[current_stage]->get_member(current_mem));
	if(q_scanning) emit signal_ping_start(find_next_to_scan());
}

void c_tree::slot_start_scan()
{
	if(ips_exist())
	{
		p_tupdate->start(3000);
		q_scanning=true;
		emit signal_ping_start(find_next_to_scan());
	}
}

void c_tree::slot_stop_scan()
{
	q_scanning=false;
	p_tupdate->stop();
}

QString c_tree::find_next_to_scan()
{
	while(1)
	{
		if(current_stage==0)
		{
			current_stage=stages.count()-1;
			current_mem=0;
			current_pc=0;
			for(int i=0;i<members.count();i++)
			{
				members[i]->buff_to_screen();
				//repaint();
			}
		}
		if(stages[current_stage]->get_n()>0)
		{
			if(current_mem<stages[current_stage]->get_n()-1)
			{
				current_mem++;
				current_pc=0;
			}else
			{
				current_mem=0;
				current_stage--;
				current_pc=0;
			}
		}else
		{
			current_mem=0;
			current_stage--;
			current_pc=0;
		}
		if(stages[current_stage]->get_n()>0)
		if(!stages[current_stage]->get_member(current_mem)->get_buf())
		if(stages[current_stage]->get_member(current_mem)->get_n_pcs()>0)
		{
			while(1)
			{
				if(stages[current_stage]->get_member(current_mem)->get_pc(current_pc)->get_ip()!="")
				{
					return stages[current_stage]->get_member(current_mem)->get_pc(current_pc)->get_ip();
				}	
				current_pc++;
				if(current_pc>=stages[current_stage]->get_member(current_mem)->get_n_pcs())
				{
					current_pc=0;
					break;	
				}
			}
		}
	}
	return "";
}

void c_tree::set_member_on(Member* mem)
{
	Member* m;
	m=mem;
	m->set_buf_on();
	while(m!=root_mem)
	{
		m=qobject_cast<Member*>(m->parent());
		m->set_buf_on();
	}
}

bool c_tree::ips_exist()
{
	for(int i=0;i<members.count();i++)
	if(members[i]->get_n_pcs())
	{
		for(int j=0;j<members[i]->get_n_pcs();j++)
		{
			if(members[i]->get_pc(j)->get_ip()!="")return true;
		}	
	}
	return false;
}

void c_tree::members_to_combobox()
{
	emit signal_root_clear();
	if(members.count()>0)
	for(int i=0; i<members.count(); i++)
	{
		emit signal_root_add(members[i]->get_name().mid(1,members[i]->get_name().length()-1));
	}
	if(mem_hided.count()>0)
	for(int i=0; i<mem_hided.count(); i++)
	{
		emit signal_root_add(mem_hided[i]->get_name().mid(1,mem_hided[i]->get_name().length()-1));
	}
	emit signal_root_set(root_mem->get_name());
}


int c_tree::get_max_x()
{
	int max;
	if(members.count()>0)
	{	
		max=members[0]->get_pos().x();
		for(int i=0; i<members.count();i++)
		{
			if(members[i]->get_pos().x()>max)max=members[i]->get_pos().x();
		}
		return max+block_width;
	}
	return 0;	
}

int c_tree::get_max_y()
{
	int max;
	if(members.count()>0)
	{	
		max=members[0]->get_pos().y()+members[0]->get_height();
		for(int i=0; i<members.count();i++)
		{
			if(members[i]->get_pos().y()+members[i]->get_height()>max)max=members[i]->get_pos().y()+members[i]->get_height();
		}
		return max;
	}
	return 0;
}

void c_tree::wheelEvent(QWheelEvent* event)
{
}

void c_tree::slot_switch_cut()
{
	//find perrent and disconnect
	mem_cutted=members[mem_finded];
	qobject_cast<Member*>(mem_cutted->parent())->delete_children(mem_cutted->get_name());
	//recursive copy all cutted members to buffer mem_cut
	mem_cut.clear();
	cut_member(mem_cutted);
	
	act_paste->setEnabled(true);
	
	emit signal_changed();
	slot_redraw_members();
}

void c_tree::slot_switch_paste()
{
	if(mem_cut.count()>0)
	{
		for(int i=0; i<mem_cut.count(); i++)
		{
			members.append(mem_cut[i]);	
		}	
		mem_cutted->setParent(members[mem_finded]);
		members[mem_finded]->add_children(mem_cutted->get_name());
	}
	emit signal_changed();
	slot_redraw_members();
	act_paste->setEnabled(false);
}

void c_tree::cut_member(Member* mem)
{	
	mem_cut.append(mem);
	if(mem->get_childrens_count()>0)
	{
		for(int i=0; i<mem->get_childrens_count();i++)
		cut_member(find_member(mem->get_children(i)));	
	}
	members.removeOne(mem);
}

void c_tree::slot_switch_rename()
{
	bool bOk, exist;
	QString str=QInputDialog::getText(0, str_rename+" "+members[mem_finded]->get_name().mid(1, members[mem_finded]->get_name().length()-1), str_new, QLineEdit::Normal, "", &bOk);
	while(str.indexOf(" ")!=-1)
	{
		str.replace(str.indexOf(" "), 1, "_");	
	}
	if(bOk && (str!=""))
	{
		exist=false;
		for(int i=0; i<members.count();i++)
		{
			if(members[i]->get_name()=="+"+str)
			{
				exist=true;
				break;	
			}	
		}
		if(!exist)
		{
			if(members[mem_finded]!=root_mem)
			{
				qobject_cast<Member*>(members[mem_finded]->parent())->delete_children(members[mem_finded]->get_name());
				qobject_cast<Member*>(members[mem_finded]->parent())->add_children("+"+str);
			}
			members[mem_finded]->set_name("+"+str);
			emit signal_changed();
			slot_redraw_members();
		}else
		{
			QMessageBox::warning(0, str_var, str_olr_ex, QMessageBox::Ok, QMessageBox::Ok);
		}
	}
}

void c_tree::slot_root_changed(QString str)
{
	show_all_members();
	hide_members(find_member("+"+str));
	tr_x=10;
	tr_y=5;
	slot_redraw_members();
}

void c_tree::hide_members(Member* mem)
{
	new_root_mem=mem;
	//save root-mem hildren
	old_root_mem=root_mem;
	//hide
	mem_hided.clear();
	recursive_hide(old_root_mem);
	//set new root-mem children
	root_mem=new_root_mem;	
}

void c_tree::show_all_members()
{
	if(mem_hided.count()>0)
	{
		for(int i=0; i<mem_hided.count(); i++)
		{
			members.append(mem_hided[i]);	
		}	
		mem_hided.clear();
		root_mem=old_root_mem;
	}
}

void c_tree::recursive_hide(Member* mem)
{
	if(mem!=new_root_mem)
	{
		mem_hided.append(mem);
		if(mem->get_childrens_count()>0)
		{
			for(int i=0; i<mem->get_childrens_count();i++)
			recursive_hide(find_member(mem->get_children(i)));	
		}
		members.removeOne(mem);
	}
}

void c_tree::slot_show_all()
{
	show_all_members();
	tr_x=10;
	tr_y=5;
	slot_redraw_members();
}

void c_tree::slot_find_member(QString str)
{
	Member* mem;
	bool q_finded=false;
	if(members.count()>0)
	{
		mem=root_mem;
		for(int i=0; i<members.count(); i++)
		{
			if(members[i]->get_name()=="+"+str)
			{
				mem=members[i];
				q_finded=true;
				break;
			}	
		}
		if(!q_finded)
		{
			for(int i=0; i<members.count(); i++)
			{
				if(members[i]->get_n_pcs()!=0)
				for(int j=0; j<members[i]->get_n_pcs(); j++)
				{
					if(members[i]->get_pc(j)->get_name()==str)
					{
						mem=members[i];
						q_finded=true;
						break;	
					}
				}	
			}	
		}
	}
	if(q_finded)
	{
		tr_x=(-1)*mem->get_pos().x()+25;
		tr_y=(-1)*mem->get_pos().y()+20;
		repaint();
	}else
	{
		QMessageBox::information(0, str_info, str_not_finded, QMessageBox::Ok, QMessageBox::Ok);
	}
}

void c_tree::slot_retranslate_ui(QString lang)
{
	current_language=lang;
	act_correct_pc->setText(tr("Correct pcs"));
	act_correct_sw->setText(tr("Correct switches"));
	act_cut->setText(tr("Cut"));
	act_paste->setText(tr("Paste"));
	act_rename->setText(tr("Rename"));
	str_var=tr("Warning");
	str_olr_ex=tr("This name is already exist!");
	str_var_sw=tr("This switch is olready exist!");
	str_info=tr("Information");
	str_not_finded=tr("This name was not finded!");
	str_rename=tr("Rename switch ");
	str_new=tr("New name:");
}

void c_tree::slot_request(int combo, bool st, QString str)
{
	QRegExp reg(str);
	bool qn,qi,qm,qd,qa;
	QString name, ip, mac, dep, additional;
	if(members.count()>0)
	{
		for(int i=0; i<members.count(); i++)
		{
			if(members[i]->get_n_pcs()>0)
			for(int j=0; j<members[i]->get_n_pcs(); j++)
			{
				//combo: all; name; ip, mac, dep, add
				name=members[i]->get_pc(j)->get_name();
				ip=members[i]->get_pc(j)->get_ip();
				mac=members[i]->get_pc(j)->get_mac();
				dep=members[i]->get_pc(j)->get_dep();
				additional=members[i]->get_pc(j)->get_additional();
				qn=((reg.indexIn(name)==0)&&(st))||((reg.indexIn(name)>=0)&&(!st));
				qi=((reg.indexIn(ip)==0)&&(st))||((reg.indexIn(ip)>=0)&&(!st));
				qm=((reg.indexIn(mac)==0)&&(st))||((reg.indexIn(mac)>=0)&&(!st));
				qd=((reg.indexIn(dep)==0)&&(st))||((reg.indexIn(dep)>=0)&&(!st));
				qa=((reg.indexIn(additional)==0)&&(st))||((reg.indexIn(additional)>=0)&&(!st));
				switch(combo)
				{
					case 0:
					if(qn||qi||qm|qd|qa) emit signal_add_item(name, ip, mac, dep, additional); break;
					case 1:
					if(qn) emit signal_add_item(name, ip, mac, dep, additional); break;
					case 2:
					if(qi) emit signal_add_item(name, ip, mac, dep, additional); break;
					case 3:
					if(qm) emit signal_add_item(name, ip, mac, dep, additional); break;
					case 4:
					if(qd) emit signal_add_item(name, ip, mac, dep, additional); break;
					case 5:
					if(qa) emit signal_add_item(name, ip, mac, dep, additional); break;	
				}
			}
		}	
	}
}
