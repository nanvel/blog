//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef C_ADD_PC_H
#define C_ADD_PC_H

#include <QDialog>

class Member;
class QLineEdit;
class QListWidgetItem;
class QListWidget;

class c_add_pc: public QDialog
{
	Q_OBJECT
	QLineEdit* peditpc;
	QLineEdit* peditip;
	QLineEdit* plemac;
	QLineEdit* pledep;
	QLineEdit* pleadditional;
	QListWidget* lwg;
	Member* m;
	
public:
    c_add_pc(Member*, QString, QWidget *parent = 0);
    
signals:
	void signal_redraw_members();
    
private slots:
	void slot_item_clicked(QListWidgetItem*);
	void slot_delete_record();
	void slot_change_record();
};

#endif
