//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "c_add_sw.h"
#include <QtGui>
#include "member.h"

c_add_sw::c_add_sw(Member* mem, QString lang, QWidget *parent):QDialog(parent)
{
	//i18n
	QTranslator translator;
	translator.load(lang, ":/translations"); 
	qApp->installTranslator(&translator);
	//
	pmem=mem;
	QVBoxLayout* pvbox=new QVBoxLayout;
	QLabel* plbl=new QLabel(tr("<html><table width=\"100%\"><tr><td><hr></td><td>Switch name = ")+mem->get_name().mid(1,mem->get_name().length()-1)+"</td></tr></table></html>");
	pvbox->addWidget(plbl);
	plw=new QListWidget;
	connect(plw,SIGNAL(itemClicked(QListWidgetItem*)),this,SLOT(slot_item_clicked(QListWidgetItem*)));
	QListWidgetItem* pitem=0;
	peditname=new QLineEdit("");
	QString str;
	if(mem->get_childrens_count()>0)
	{
		for(int i=0;i<mem->get_childrens_count();i++)
		{
			str=mem->get_children(i).mid(1,mem->get_children(i).length()-1);
			pitem=new QListWidgetItem(tr("Switch ")+str, plw);
		}
		peditname->setText(str);
	}
	pvbox->addWidget(plw);
	
	QGridLayout* boxedit=new QGridLayout;
	QLabel* lblname=new QLabel(tr("Switch:"));
	boxedit->addWidget(lblname,0,0,1,1);
	boxedit->addWidget(peditname,0,1,1,1);
	
	pvbox->addLayout(boxedit);
	
	QHBoxLayout* phbox=new QHBoxLayout();
	QPushButton* pcmdexit=new QPushButton(tr("Exit"));
	connect(pcmdexit,SIGNAL(clicked()),this,SLOT(close()));
	QPushButton* pcmddelete=new QPushButton(tr("Delete"));
	connect(pcmddelete,SIGNAL(clicked()),this,SLOT(slot_delete_record()));
	QPushButton* pcmdcorrect=new QPushButton(tr("Add"));
	connect(pcmdcorrect,SIGNAL(clicked()),this,SLOT(slot_correct_record()));
	connect(peditname, SIGNAL(returnPressed()), this, SLOT(slot_correct_record()));
	phbox->addWidget(pcmdexit);
	phbox->addStretch();
	phbox->addWidget(pcmddelete);
	phbox->addWidget(pcmdcorrect);
	pvbox->addLayout(phbox);
	setLayout(pvbox);
	setTabOrder(peditname, pcmdcorrect);
	setTabOrder(pcmdcorrect, pcmddelete);
	setTabOrder(pcmddelete, pcmdexit);
	peditname->setFocus();
	setWindowTitle(tr("Edit switches"));
}

void c_add_sw::slot_delete_record()
{
	QList<QListWidgetItem*> lst;
	lst= plw->findItems(tr("Switch ")+peditname->text(),Qt::MatchExactly);
	if(!(lst.isEmpty()))
	{
		delete lst[0];
		emit signal_delete_switch("+"+peditname->text());
		pmem->delete_children("+"+peditname->text());
		emit signal_rebuilt_tree();
	}	
	peditname->setFocus();
}

void c_add_sw::slot_correct_record()
{
	QString name;
	name=peditname->text();
	while(name.indexOf(" ")!=-1)
	{
		name.replace(name.indexOf(" "), 1, "_");	
	}
	peditname->setText(name);
	emit signal_add_switch(pmem, "+"+name);
	peditname->setFocus();
}

void c_add_sw::slot_item_clicked(QListWidgetItem* item)
{
	peditname->setText(item->text().mid(item->text().lastIndexOf(" ")+1,item->text().length()- item->text().lastIndexOf(" ")));
}

void c_add_sw::slot_add_item()
{
	QListWidgetItem* temp_item;
	temp_item=new QListWidgetItem(tr("Switch ")+peditname->text(), plw);
	emit signal_rebuilt_tree();
}
