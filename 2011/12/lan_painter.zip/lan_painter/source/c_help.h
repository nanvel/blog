//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef C_HELP_H
#define C_HELP_H

#include <QDialog>

class c_help: public QDialog
{
	Q_OBJECT
	
public:
	c_help(QString, QWidget* parent=0);
	
};

#endif
