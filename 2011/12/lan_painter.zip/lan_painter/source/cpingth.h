//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef _CPINGTH_H
#define _CPINGTH_H

#include <QThread>
#include <QHostInfo>

class CPingTh : public QThread
{
	Q_OBJECT
	QString ping_ip;
public:
	void run();
	
signals:
	void signal_ping_ok(QString, int);
	
public slots:
	void slot_make_ping(QString);
	void slot_ping_ok(QHostInfo);
};

#endif
