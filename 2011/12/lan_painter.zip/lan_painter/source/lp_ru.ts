<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>D_Data</name>
    <message>
        <location filename="params.cpp" line="41"/>
        <source>Data file:</source>
        <translation>Файл с данными:</translation>
    </message>
    <message>
        <location filename="params.cpp" line="52"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="params.cpp" line="56"/>
        <source>Save as</source>
        <translation>Сохранить как</translation>
    </message>
    <message>
        <location filename="params.cpp" line="83"/>
        <source>Select file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="params.cpp" line="121"/>
        <source>Save us</source>
        <translation>Сохранить как</translation>
    </message>
</context>
<context>
    <name>D_Window</name>
    <message>
        <location filename="params.cpp" line="68"/>
        <source>Select language:</source>
        <translation>Выберите язык:</translation>
    </message>
    <message>
        <location filename="params.cpp" line="72"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="params.cpp" line="72"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="params.cpp" line="72"/>
        <source>Ukrainian</source>
        <translation>Українська</translation>
    </message>
</context>
<context>
    <name>Params</name>
    <message>
        <location filename="params.cpp" line="27"/>
        <source>Data</source>
        <translation>Данные</translation>
    </message>
    <message>
        <location filename="params.cpp" line="28"/>
        <source>Window</source>
        <translation>Вид</translation>
    </message>
</context>
<context>
    <name>Window</name>
    <message>
        <location filename="window.cpp" line="26"/>
        <location filename="window.cpp" line="252"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="window.cpp" line="30"/>
        <location filename="window.cpp" line="253"/>
        <source>Hide</source>
        <translation>Свернуть окно в область оповещений</translation>
    </message>
    <message>
        <location filename="window.cpp" line="34"/>
        <location filename="window.cpp" line="254"/>
        <source>Help</source>
        <translation>Помощ</translation>
    </message>
    <message>
        <location filename="window.cpp" line="38"/>
        <location filename="window.cpp" line="255"/>
        <source>Save PDF</source>
        <translation>Сохранить как PDF</translation>
    </message>
    <message>
        <location filename="window.cpp" line="42"/>
        <location filename="window.cpp" line="256"/>
        <source>Parameters</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <location filename="window.cpp" line="46"/>
        <location filename="window.cpp" line="257"/>
        <source>Scan/Stop</source>
        <translation>Начать/Остановить сканирование</translation>
    </message>
    <message>
        <location filename="window.cpp" line="51"/>
        <source>View information</source>
        <translation>Показать информацию</translation>
    </message>
    <message>
        <location filename="window.cpp" line="70"/>
        <location filename="window.cpp" line="258"/>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <location filename="window.cpp" line="71"/>
        <location filename="window.cpp" line="259"/>
        <source>Show all</source>
        <translation>Показать все</translation>
    </message>
    <message>
        <location filename="window.cpp" line="73"/>
        <location filename="window.cpp" line="260"/>
        <source>Find: </source>
        <translation>Найти: </translation>
    </message>
    <message>
        <location filename="window.cpp" line="74"/>
        <location filename="window.cpp" line="261"/>
        <source>Root: </source>
        <translation>Корень: </translation>
    </message>
    <message>
        <location filename="window.cpp" line="96"/>
        <location filename="window.cpp" line="262"/>
        <source>Show/hide application window</source>
        <translation>Показать/Скрыть окно приложения</translation>
    </message>
    <message>
        <location filename="window.cpp" line="112"/>
        <location filename="window.cpp" line="263"/>
        <source>Lan painter</source>
        <translation>Lan painter</translation>
    </message>
    <message>
        <location filename="window.cpp" line="264"/>
        <source>Save?</source>
        <translation>Сохранить?</translation>
    </message>
    <message>
        <location filename="window.cpp" line="265"/>
        <source>Data was changed, save?</source>
        <translation>Данные были изменены, сохранить?</translation>
    </message>
</context>
<context>
    <name>c_add_pc</name>
    <message>
        <location filename="c_add_pc.cpp" line="45"/>
        <source>&lt;html&gt;&lt;table width=&quot;100%&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;hr&gt;&lt;/td&gt;&lt;td&gt;Switch name = </source>
        <translation>&lt;html&gt;&lt;table width=&quot;100%&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;hr&gt;&lt;/td&gt;&lt;td&gt;Коммутатор = </translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="50"/>
        <source>Name:</source>
        <translation>Имя:</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="51"/>
        <source>ip:</source>
        <translation>IP:</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="60"/>
        <source>MAC:</source>
        <translation>MAC:</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="61"/>
        <source>Dep:</source>
        <translation>Отдел:</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="62"/>
        <source>Additional:</source>
        <translation>Дополнительно:</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="79"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="81"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="83"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="c_add_pc.cpp" line="103"/>
        <source>Edit pcs</source>
        <translation>Корректировка списка компьютеров</translation>
    </message>
</context>
<context>
    <name>c_add_sw</name>
    <message>
        <location filename="c_add_sw.cpp" line="20"/>
        <source>&lt;html&gt;&lt;table width=&quot;100%&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;hr&gt;&lt;/td&gt;&lt;td&gt;Switch name = </source>
        <translation>&lt;html&gt;&lt;table width=&quot;100%&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;hr&gt;&lt;/td&gt;&lt;td&gt;Коммутатор = </translation>
    </message>
    <message>
        <location filename="c_add_sw.cpp" line="32"/>
        <location filename="c_add_sw.cpp" line="69"/>
        <location filename="c_add_sw.cpp" line="101"/>
        <source>Switch </source>
        <translation>Коммутатор </translation>
    </message>
    <message>
        <location filename="c_add_sw.cpp" line="39"/>
        <source>Switch:</source>
        <translation>Коммутатор:</translation>
    </message>
    <message>
        <location filename="c_add_sw.cpp" line="46"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="c_add_sw.cpp" line="48"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="c_add_sw.cpp" line="50"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="c_add_sw.cpp" line="63"/>
        <source>Edit switches</source>
        <translation>Корректировка списка коммутаторов</translation>
    </message>
</context>
<context>
    <name>c_help</name>
    <message>
        <location filename="c_help.cpp" line="21"/>
        <source>:/help/help_ru.html</source>
        <translation>:/help/help_ru.html</translation>
    </message>
    <message>
        <location filename="c_help.cpp" line="34"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="c_help.cpp" line="49"/>
        <source>Help</source>
        <translation>Помощ</translation>
    </message>
</context>
<context>
    <name>c_tree</name>
    <message>
        <location filename="c_tree.cpp" line="19"/>
        <location filename="c_tree.cpp" line="1072"/>
        <source>Correct pcs</source>
        <translation>Корректировать список компьютеров</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="22"/>
        <location filename="c_tree.cpp" line="1073"/>
        <source>Correct switches</source>
        <translation>Корректировать список коммутаторов</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="25"/>
        <location filename="c_tree.cpp" line="1074"/>
        <source>Cut</source>
        <translation>Вырезать</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="28"/>
        <location filename="c_tree.cpp" line="1075"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="32"/>
        <location filename="c_tree.cpp" line="1076"/>
        <source>Rename</source>
        <translation>Переименовать</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="55"/>
        <location filename="c_tree.cpp" line="1077"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="57"/>
        <location filename="c_tree.cpp" line="1079"/>
        <source>This switch is olready exist!</source>
        <translation>Такое имя коммутатора уже используется!</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="60"/>
        <location filename="c_tree.cpp" line="1082"/>
        <source>Rename switch </source>
        <translation>Переименовать коммутатор</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="61"/>
        <location filename="c_tree.cpp" line="1083"/>
        <source>New name:</source>
        <translation>Новое имя:</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="56"/>
        <location filename="c_tree.cpp" line="1078"/>
        <source>This name is already exist!</source>
        <translation>Это имя уже используется!</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="58"/>
        <location filename="c_tree.cpp" line="1080"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="c_tree.cpp" line="59"/>
        <location filename="c_tree.cpp" line="1081"/>
        <source>This name was not finded!</source>
        <translation>Обьекта с таким именем не найдено!</translation>
    </message>
</context>
<context>
    <name>c_view</name>
    <message>
        <location filename="c_view.cpp" line="15"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="15"/>
        <location filename="c_view.cpp" line="86"/>
        <location filename="c_view.cpp" line="110"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="15"/>
        <location filename="c_view.cpp" line="86"/>
        <location filename="c_view.cpp" line="110"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="15"/>
        <location filename="c_view.cpp" line="86"/>
        <location filename="c_view.cpp" line="110"/>
        <source>MAC</source>
        <translation>MAC</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="15"/>
        <location filename="c_view.cpp" line="86"/>
        <location filename="c_view.cpp" line="110"/>
        <source>Department</source>
        <translation>Отдел</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="15"/>
        <location filename="c_view.cpp" line="86"/>
        <location filename="c_view.cpp" line="110"/>
        <source>Additional</source>
        <translation>Дополнительно</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="19"/>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="21"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="23"/>
        <source>Save as HTML</source>
        <translation>Сохранить как HTML</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="26"/>
        <source>From start</source>
        <translation>Начинается с</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="28"/>
        <source>Inner</source>
        <translation>Внутри</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="53"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="92"/>
        <source>Save table as HTML</source>
        <translation>Сохранить таблицу в формате HTML</translation>
    </message>
    <message>
        <location filename="c_view.cpp" line="110"/>
        <source>N</source>
        <translation>N</translation>
    </message>
</context>
</TS>
