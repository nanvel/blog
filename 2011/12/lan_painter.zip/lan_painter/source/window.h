//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef WINDOW_H
#define WINDOW_H

#include <QMainWindow>
#include <QTime>

class c_tree;
class QSystemTrayIcon;
class QMenu;
class CPingTh;
class QComboBox;
class QLineEdit;
class QAction;
class QLabel;

class Window: public QMainWindow
{
	Q_OBJECT
	c_tree* tree;
	QSystemTrayIcon* ptray;
	QMenu* ptraymenu; 
	CPingTh* thread;
	QString current_file;
	void load_params();
	QTime time;
	QComboBox* prootsel;
	QLineEdit* pefind;
	QAction* pactexit;
	QAction* pact_hide;
	QAction* pactabout;
	QAction* act_save_pdf;
	QAction* act_params;
	QAction* act_scan;
	QAction* act_find;
	QAction* act_show_all;
	QLabel* plfind;
	QLabel* plroot;
	QAction* pactshowhide;
	QAction* act_data;
	//
	QString current_language;
	QString str_save, str_data_ch;
	//
	bool changed;
	
public:
	Window(QWidget *parent = 0);
    
protected:

signals:
	void signal_ping(QString);
	void signal_file_changed(QString);
	void signal_file_reload();
	void signal_start_scan();
	void signal_stop_scan();
	void signal_find_member(QString);
	void signal_retranslate_ui(QString);
	void signal_save_data();

private slots:
	void slot_show_view();

public slots:
	void slot_params();
	void slot_show_hide();
	void slot_exit();
	void slot_info();
	void slot_ping_start(QString);
	void slot_scan(bool);
	void slot_root_clear();
	void slot_root_add(QString);
	void slot_root_set(QString);
	void slot_find();
	void slot_change_language(QString);
	void slot_retranslate_ui(QString);
	void slot_changed();
	void slot_saved();

};

#endif
