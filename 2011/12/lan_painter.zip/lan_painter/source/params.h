//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef PARAMS_H
#define PARAMS_H

#include <QDialog>

class QLineEdit;
class QLabel;

class D_Window: public QWidget
{
	Q_OBJECT
	
	QLabel* plbl;
public:
    D_Window(QWidget *parent = 0);
    
signals:
    void signal_change_language(QString);
    
private slots:
	void slot_change_language(int);
};

class D_Data: public QWidget
{
	Q_OBJECT
	
	QLineEdit* p_cur_file;
	QString select_file(QString, unsigned char);
	QString current_file;
	
public:
    D_Data(QString, QWidget *parent = 0);

signals:
	void signal_file_changed(QString);
	void signal_file_reload();
	void signal_file_save();

private slots:
	void slot_select_file();
	void slot_save_us();

};

class Params: public QDialog
{
	Q_OBJECT
	
public:
    Params(QString, QString, QWidget *parent = 0);
    
signals:
	void signal_file_changed(QString);
	void signal_file_reload();
	void signal_file_save();
	void signal_change_language(QString);
};

#endif
