//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "params.h"
#include <QtGui>

Params::Params(QString cur_file, QString lang, QWidget *parent) :  QDialog(parent)
{
	//i18n
	QTranslator translator;
	translator.load(lang, ":/translations"); 
	qApp->installTranslator(&translator);
	//
	
	D_Data* data=new D_Data(cur_file);
	connect(data, SIGNAL(signal_file_changed(QString)),this,SIGNAL(signal_file_changed(QString)));
	connect(data, SIGNAL(signal_file_reload()),this,SIGNAL(signal_file_reload()));
	connect(data, SIGNAL(signal_file_save()),this,SIGNAL(signal_file_save()));
	
	D_Window* win=new D_Window;
	connect(win, SIGNAL(signal_change_language(QString)), this, SIGNAL(signal_change_language(QString)));
	
	QToolBox* ptab=new QToolBox;
	ptab->addItem(data,QPixmap(":/images/data.png"),tr("Data"));
	ptab->addItem(win,QPixmap(":/images/window.png"),tr("Window"));
	
	QHBoxLayout* hbox=new QHBoxLayout;
	
	hbox->addWidget(ptab);
	
	setLayout(hbox);
}

D_Data::D_Data(QString cur_file, QWidget *parent) :  QWidget(parent)
{
	current_file=cur_file;
	QVBoxLayout* vbox=new QVBoxLayout;
	vbox->addWidget(new QLabel(tr("Data file:")));
	QHBoxLayout* hbox=new QHBoxLayout;
	p_cur_file=new QLineEdit(this);
	p_cur_file->setReadOnly(true);
	p_cur_file->setText(cur_file);
	QPushButton* p_cmd_select= new QPushButton(this);
	connect(p_cmd_select, SIGNAL(clicked()),this,SLOT(slot_select_file()));
	p_cmd_select->setIcon(QPixmap(":/images/pencil.png"));
	hbox->addWidget(p_cur_file);
	hbox->addWidget(p_cmd_select);
	vbox->addLayout(hbox);
	QPushButton* p_cmd_save=new QPushButton(tr("Save"),this);
	p_cmd_save->setIcon(QPixmap(":/images/save.png"));
	connect(p_cmd_save, SIGNAL(clicked()),this, SIGNAL(signal_file_save()));
	vbox->addWidget(p_cmd_save);
	QPushButton* p_cmd_save_us=new QPushButton(tr("Save as"),this);
	p_cmd_save_us->setIcon(QPixmap(":/images/save_as.png"));
	connect(p_cmd_save_us, SIGNAL(clicked()),this, SLOT(slot_save_us()));
	vbox->addWidget(p_cmd_save_us);
	vbox->addStretch();
	
	setLayout(vbox);
}

D_Window::D_Window(QWidget *parent) :  QWidget(parent)
{	
	QVBoxLayout* vbox=new QVBoxLayout;
	plbl=new QLabel(tr("Select language:"));
	vbox->addWidget(plbl);
	QComboBox* p_lang=new QComboBox(this);
	QStringList lang_lst;
	lang_lst << tr("English") << tr("Russian") << tr("Ukrainian");
	p_lang->addItems(lang_lst);
	p_lang->setCurrentIndex(-1);
	connect(p_lang, SIGNAL(currentIndexChanged(int)), this, SLOT(slot_change_language(int)));
	vbox->addWidget(p_lang);
	vbox->addStretch();
	setLayout(vbox);
}

void D_Data::slot_select_file()
{
	QString f_name=select_file(tr("Select file"),0);
	if(f_name!="")
	{
		current_file=f_name;
		p_cur_file->setText(current_file);
		
		QSettings settings("DonSTU","LanPainter");
		settings.setValue("/Save/current_file",current_file);
		
		emit(signal_file_changed(current_file));
		emit(signal_file_reload());
	}
}

QString D_Data::select_file(QString mes, unsigned char qsave)
{
	QFileDialog fileDialog(this, mes);
    QString file_name;
    fileDialog.setDefaultSuffix("lmr");
    if(qsave)
    fileDialog.setAcceptMode(QFileDialog::AcceptSave);
    else
    fileDialog.setAcceptMode(QFileDialog::AcceptOpen);
    fileDialog.setConfirmOverwrite(true);
    fileDialog.setDirectory(".");
    fileDialog.setFileMode(QFileDialog::AnyFile);
    fileDialog.setFilter("lmr-files *.lmr");
    if(fileDialog.exec())
    {
        file_name=fileDialog.selectedFiles().at(0);
        if(file_name!="")return file_name;
    }	
    return "";
}

void D_Data::slot_save_us()
{
	QString fname;
	fname=select_file(tr("Save us"),1);
	if(fname!="")
	{
		emit signal_file_changed(fname);
		emit signal_file_save();
		emit signal_file_changed(current_file);
	}
}

void D_Window::slot_change_language(int str)
{
	QString lng_file;
	if(str==1)lng_file="lp_ru.qm"; else
	if(str==2)lng_file="lp_uk.qm"; else
	lng_file="lp_en.qm";
	//save
	QSettings settings("DonSTU","LanPainter");
	settings.setValue("/Save/current_language", lng_file);
	//save
	emit signal_change_language(lng_file);
}
