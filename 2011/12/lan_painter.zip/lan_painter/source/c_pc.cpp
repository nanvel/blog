//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "c_pc.h"

c_pc::c_pc(QString n, QObject* parent):QObject(parent)
{
	name=n;
	ip="";
	mac="";
	dep="";
	additional="";
}
