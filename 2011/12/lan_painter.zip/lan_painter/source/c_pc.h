//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef C_PC_H
#define C_PC_H

#include <QObject>

class c_pc: public QObject
{
	Q_OBJECT
	QString name;
	QString ip;
	QString mac;
	QString dep;
	QString additional;
	
public:
	c_pc(QString, QObject* parent=0);
	void set_name(QString n){name=n;}
	void set_ip(QString i){ip=i;};
	void set_mac(QString m){mac=m;};
	void set_dep(QString d){dep=d;};
	void set_additional(QString a){additional=a;};
	
	QString get_name(){return name;};
	QString get_ip(){return ip;};
	QString get_mac(){return mac;};
	QString get_dep(){return dep;};
	QString get_additional(){return additional;};
};

#endif
