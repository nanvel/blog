//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "window.h"
#include "c_tree.h"
#include "params.h"
#include "cpingth.h"
#include "c_help.h"
#include <QtGui>
#include "c_view.h"

Window::Window(QWidget *parent) :  QMainWindow(parent)
{
	tree=new c_tree;
	
	connect(tree, SIGNAL(signal_root_clear()), this, SLOT(slot_root_clear()));
	connect(tree, SIGNAL(signal_root_add(QString)), this, SLOT(slot_root_add(QString)));
	connect(this, SIGNAL(signal_retranslate_ui(QString)), tree, SLOT(slot_retranslate_ui(QString)));
	connect(this, SIGNAL(signal_retranslate_ui(QString)), this, SLOT(slot_retranslate_ui(QString)));
	connect(this,SIGNAL(signal_save_data()), tree, SLOT(slot_file_save()));
	connect(tree, SIGNAL(signal_changed()), this, SLOT(slot_changed()));
	
	pactexit=new QAction(QIcon(":/images/exit.png"),tr("Exit"),this);
	connect(pactexit, SIGNAL(triggered()), this, SLOT(slot_exit()));
	pactexit->setIconVisibleInMenu(true);
	
	pact_hide=new QAction(QIcon(":/images/hide.png"), tr("Hide"), this);
	pact_hide->setIconVisibleInMenu(true);
	connect(pact_hide, SIGNAL(triggered()), this, SLOT(slot_show_hide()));
	
	pactabout=new QAction(QIcon(":/images/about.png"),tr("Help"), this);
	pactabout->setIconVisibleInMenu(true);
	connect(pactabout, SIGNAL(triggered()), this, SLOT(slot_info()));
	
	act_save_pdf= new QAction(QIcon(":/images/save_pdf.png"), tr("Save PDF"), this);
	act_save_pdf->setIconVisibleInMenu(true);
	connect(act_save_pdf,SIGNAL(triggered()),tree,SLOT(slot_print_pdf()));
	
	act_params= new QAction(QIcon(":/images/params.png"), tr("Parameters"), this);
	act_params->setIconVisibleInMenu(true);
	connect(act_params,SIGNAL(triggered()),this,SLOT(slot_params()));
	
	act_scan= new QAction(QIcon(":/images/scan.png"), tr("Scan/Stop"), this);
	act_scan->setIconVisibleInMenu(true);
	act_scan->setCheckable(true);
	connect(act_scan, SIGNAL(toggled(bool)),this, SLOT(slot_scan(bool)));
	
	act_data= new QAction(QIcon(":/images/data_find.png"), tr("View information"), this);
	act_data->setIconVisibleInMenu(true);
	connect(act_data, SIGNAL(triggered()), this, SLOT(slot_show_view()));
	
	QToolBar* tbar=new QToolBar;
	
	tbar->setMovable(false);
	tbar->addAction(act_params);
	tbar->addSeparator();
	tbar->addAction(act_scan);
	tbar->addAction(act_data);
	tbar->addSeparator();
	tbar->addAction(pactabout);
	tbar->addSeparator();
	tbar->addAction(pact_hide);
	tbar->addAction(pactexit);
	
	addToolBar(tbar);
	
	act_find= new QAction(QIcon(":/images/find.png"), tr("Find"), this);
	act_show_all= new QAction(QIcon(":/images/show_all.png"), tr("Show all"), this);
	connect(act_show_all, SIGNAL(triggered()), tree, SLOT(slot_show_all()));
	plfind=new QLabel(tr("Find: "));
	plroot=new QLabel(tr("Root: "));
	pefind=new QLineEdit;
	prootsel=new QComboBox;
	connect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
	connect(tree, SIGNAL(signal_root_set(QString)), this, SLOT(slot_root_set(QString)));
	QToolBar* botbar=new QToolBar;
	botbar->addAction(act_save_pdf);
	botbar->addSeparator();
	//botbar->setMovable(false);
	botbar->addWidget(plroot);
	botbar->addWidget(prootsel);
	botbar->addAction(act_show_all);
	botbar->addSeparator();
	botbar->addWidget(plfind);
	botbar->addWidget(pefind);
	botbar->addAction(act_find);
	connect(act_find, SIGNAL(triggered()), this, SLOT(slot_find()));
	connect(pefind, SIGNAL(returnPressed()), this, SLOT(slot_find()));
	connect(this, SIGNAL(signal_find_member(QString)), tree, SLOT(slot_find_member(QString)));
	addToolBar(botbar);
	
	//tray icon
	pactshowhide= new QAction(QIcon(":/images/hide.png"),tr("Show/hide application window"), this);
	pactshowhide->setIconVisibleInMenu(true);
	connect(pactshowhide, SIGNAL(triggered()), this, SLOT(slot_show_hide()));
	ptraymenu= new QMenu(this);
	ptraymenu->addAction(pactshowhide);
	ptraymenu->addAction(pactexit);
	ptray= new QSystemTrayIcon(this);
	ptray->setContextMenu(ptraymenu);
	ptray->setIcon(QPixmap(":/images/icon.png"));
	ptray->show();
	
	setCentralWidget(tree);
	
	connect(this,SIGNAL(signal_file_changed(QString)), tree, SLOT(slot_file_changed(QString)));
	connect(this,SIGNAL(signal_file_reload()), tree, SLOT(slot_file_reload()));
	
	setWindowTitle(tr("Lan painter"));
	
	load_params();
	
	thread=new CPingTh;
	connect(thread, SIGNAL(signal_ping_ok(QString, int)),tree, SLOT(slot_ping_complite(QString, int)));
	connect(this, SIGNAL(signal_ping(QString)),thread, SLOT(slot_make_ping(QString)));
	connect(tree, SIGNAL(signal_ping_start(QString)),this,SLOT(slot_ping_start(QString)));
	
	connect(this, SIGNAL(signal_start_scan()),tree, SLOT(slot_start_scan()));
	connect(this, SIGNAL(signal_stop_scan()),tree, SLOT(slot_stop_scan()));
	
	pefind->setFocus();
	
	changed=false;
}

void Window::slot_params()
{
	Params params(current_file, current_language, this);
	connect(&params,SIGNAL(signal_file_changed(QString)), tree, SLOT(slot_file_changed(QString)));
	connect(&params,SIGNAL(signal_file_save()), tree, SLOT(slot_file_save()));
	connect(&params,SIGNAL(signal_file_save()), this, SLOT(slot_saved()));
	connect(&params,SIGNAL(signal_file_reload()), tree, SLOT(slot_file_reload()));
	connect(&params,SIGNAL(signal_file_reload()), this, SLOT(slot_saved()));
	connect(&params, SIGNAL(signal_change_language(QString)), this, SLOT(slot_change_language(QString)));
	params.exec();
}

void Window::slot_show_hide()
{
	setVisible(!isVisible());
}

void Window::slot_exit()
{
	int q;
	if(changed)
	{
		q=QMessageBox::question(0, str_save, str_data_ch, QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel, QMessageBox::Cancel);
		if(q==QMessageBox::Yes)
		{
			emit signal_save_data();
			qApp->quit();
		}
		if(q==QMessageBox::No)
		{
			qApp->quit();
		}	
	}
	else
	{
		qApp->quit();
	}
}

void Window::slot_info()
{
	c_help helper(current_language, this);
	helper.resize(400,200);
	helper.exec();
}

void Window::load_params()
{
	QSettings settings("DonSTU","LanPainter");
	current_file= settings.value("/Save/current_file","lan.lmr").toString();
	current_language= settings.value("/Save/current_language", "no").toString();
	if(current_language=="no")
	{
		QString str= QLocale::system().name();
		if((str=="ru")||(str=="ru_RU"))
		current_language="lp_ru.qm";else
		if(str=="uk_UA")
		current_language="lp_uk.qm"; else
		current_language="lp_en.qm";
		settings.setValue("/Save/current_language", current_language);
	}
	slot_change_language(current_language);
	emit signal_file_changed(current_file);
	emit signal_file_reload();
}

void Window::slot_ping_start(QString str)
{
	thread->exit();
	time.start();
	for(;time.elapsed()<200;)
	{
		qApp->processEvents();
	}
	emit signal_ping(str);
	thread->start();
}

void Window::slot_scan(bool q)
{
	if(q)emit signal_start_scan();
	else
	emit signal_stop_scan();
}

void Window::slot_root_clear()
{
	disconnect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
	prootsel->clear();
	connect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
}

void Window::slot_root_add(QString str)
{
	disconnect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
	prootsel->addItem(str);
	connect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
}

void Window::slot_root_set(QString str)
{
	disconnect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
	prootsel->setCurrentIndex(prootsel->findText(str.mid(1,str.length()-1)));
	connect(prootsel, SIGNAL(currentIndexChanged(QString)), tree, SLOT(slot_root_changed(QString)));
}

void Window::slot_find()
{
	emit signal_find_member(pefind->text());
	pefind->setFocus();
}

void Window::slot_change_language(QString lang)
{	
	current_language=lang;
	QTranslator translator;
	translator.load(lang, ":/translations");
	qApp->installTranslator(&translator);
	emit signal_retranslate_ui(lang);
}

void Window::slot_retranslate_ui(QString lang)
{
	pactexit->setText(tr("Exit"));
	pact_hide->setText(tr("Hide"));
	pactabout->setText(tr("Help"));
	act_save_pdf->setText(tr("Save PDF"));
	act_params->setText(tr("Parameters"));
	act_scan->setText(tr("Scan/Stop"));
	act_find->setText(tr("Find"));
	act_show_all->setText(tr("Show all"));
	act_data->setText(tr("View information"));
	plfind->setText(tr("Find: "));
	plroot->setText(tr("Root: "));
	pactshowhide->setText(tr("Show/hide application window"));
	setWindowTitle(tr("Lan painter"));
	str_save=tr("Save?");
	str_data_ch=tr("Data was changed, save?");
}

void Window::slot_changed()
{
	changed=true;	
}

void Window::slot_saved()
{
	changed=false;	
}

void Window::slot_show_view()
{
	c_view my_view(current_language, this);
	connect(&my_view, SIGNAL(signal_request(int, bool, QString)), tree, SLOT(slot_request(int, bool, QString)));
	connect(tree, SIGNAL(signal_add_item(QString, QString, QString, QString, QString)), &my_view, SLOT(slot_add_item(QString, QString, QString, QString, QString)));
	my_view.exec();
}
