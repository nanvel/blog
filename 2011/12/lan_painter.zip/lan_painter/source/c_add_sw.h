//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef C_ADD_SW_H
#define C_ADD_SW_H

#include <QDialog>

class Member;
class QLineEdit;
class QListWidget;
class QListWidgetItem;

class c_add_sw: public QDialog
{
	Q_OBJECT
	QLineEdit* peditname;
	Member* pmem;
	QListWidget* plw;
	
public:
    c_add_sw(Member*, QString, QWidget *parent = 0);
    
signals:
	void signal_delete_switch(QString);
	void signal_add_switch(Member*, QString);
	void signal_rebuilt_tree();
    
private slots:
	void slot_delete_record();
	void slot_correct_record();
	void slot_item_clicked(QListWidgetItem*);
	void slot_add_item();
};

#endif
