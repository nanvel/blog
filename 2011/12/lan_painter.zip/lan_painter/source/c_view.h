//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#ifndef C_VIEW_H
#define C_VIEW_H

#include <QDialog>

class QRadioButton;
class QComboBox;
class QLineEdit;
class QTableWidget;

class c_view:public  QDialog
{
	Q_OBJECT
	QRadioButton* prfromstart;
	QComboBox* pwhat;
	QLineEdit* pedit;
	QTableWidget* ptable;
	int counter;
	void init_table();

public:
	c_view(QString, QWidget* paret=0);
	
signals:
	void signal_request(int, bool, QString);
	
private slots:
	void slot_send_request();
	void slot_save();
	
public slots:
	void slot_add_item(QString, QString, QString, QString, QString);
};

#endif
