//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "c_help.h"
#include <QtGui>

c_help::c_help(QString lang, QWidget* parent):QDialog(parent)
{
	//i18n
	QTranslator translator;
	translator.load(lang, ":/translations"); 
	qApp->installTranslator(&translator);
	//
	
	QTextEdit* text=new QTextEdit("");
	text->setReadOnly(true);
	QString str;
	QFile file(tr(":/help/help_ru.html"));
    if(file.open(QIODevice::ReadOnly))
    {
		str="";
        QTextStream stream(&file);
        while(!stream.atEnd())
        {
			str+=stream.readLine();
		}
		text->setText(str);
	}
	
	text->setAlignment(Qt::AlignTop);
	QPushButton* cmd_exit=new QPushButton(tr("Exit"));
	connect(cmd_exit, SIGNAL(clicked()), this, SLOT(close()));
	QVBoxLayout* vbox=new QVBoxLayout;
	vbox->setMargin(3);
	vbox->setSpacing(0);
	
	vbox->addWidget(text);
	
	QHBoxLayout* hbox=new QHBoxLayout;
	hbox->addStretch();
	hbox->addWidget(cmd_exit);
	hbox->setMargin(5);
	
	vbox->addLayout(hbox);
	
	setWindowTitle(tr("Help"));
	
	setLayout(vbox); 
}
