//--------------------------------------------------------//
// This is part of the program Lan painter                //
// Copyright (C) Olexandr Polyeno (polyenoom@gmail.com)   //
// License LGPL (http://www.gnu.org/copyleft/lesser.html) //
//--------------------------------------------------------//

#include "c_view.h"
#include <QtGui>

c_view::c_view(QString lang, QWidget* parent):QDialog(parent)
{
	//i18n
	QTranslator translator;
	translator.load(lang, ":/translations"); 
	qApp->installTranslator(&translator);
	//
	
	pwhat= new QComboBox;

	QStringList lst;
	lst << tr("All") << tr("Name") << tr("IP") << tr("MAC") << tr("Department") << tr("Additional");
	pwhat->addItems(lst);

	pedit= new QLineEdit;
	QPushButton* pcmdfind= new QPushButton(tr("Find"));
	connect(pcmdfind, SIGNAL(clicked()), this, SLOT(slot_send_request()));
	QPushButton* pcmdexit= new QPushButton(tr("Exit"));
	connect(pcmdexit,SIGNAL(clicked()),this,SLOT(close()));
	QPushButton* pcmdsavehtml= new QPushButton(tr("Save as HTML"));
	connect(pcmdsavehtml, SIGNAL(clicked()), this, SLOT(slot_save()));
	ptable= new QTableWidget;
	prfromstart= new QRadioButton(tr("From start"), this);
	prfromstart->setChecked(true);
	QRadioButton* prin= new QRadioButton(tr("Inner"), this);
	
	QHBoxLayout* hbox1= new QHBoxLayout;
	hbox1->addWidget(pwhat);
	hbox1->addWidget(prfromstart);
	hbox1->addWidget(prin);
	hbox1->addStretch();
	
	QHBoxLayout* hbox2= new QHBoxLayout;
	hbox2->addWidget(pedit);
	hbox2->addWidget(pcmdfind);
	
	QHBoxLayout* hbox3= new QHBoxLayout;
	hbox3->addWidget(pcmdexit);
	hbox3->addStretch();
	hbox3->addWidget(pcmdsavehtml);
	
	QVBoxLayout* vbox= new QVBoxLayout;
	vbox->addLayout(hbox1);
	vbox->addLayout(hbox2);
	vbox->addWidget(ptable);
	vbox->addLayout(hbox3);
	
	setLayout(vbox);
	
	setWindowTitle(tr("Information"));
}

void c_view::slot_send_request()
{
	init_table();
	emit signal_request(pwhat->currentIndex(), prfromstart->isChecked(), pedit->text());
}

void c_view::slot_add_item(QString name, QString ip, QString mac, QString dep, QString additional)
{
	counter++;
	ptable->setRowCount(counter);
	QTableWidgetItem* temp;
	temp= new QTableWidgetItem(name);
	ptable->setItem(counter-1,0,temp);
	temp= new QTableWidgetItem(ip);
	ptable->setItem(counter-1,1,temp);
	temp= new QTableWidgetItem(mac);
	ptable->setItem(counter-1,2,temp);
	temp= new QTableWidgetItem(dep);
	ptable->setItem(counter-1,3,temp);
	temp= new QTableWidgetItem(additional);
	ptable->setItem(counter-1,4,temp);
} 

void c_view::init_table()
{
	counter=0;
	ptable->clear();
	ptable->setRowCount(0);
	ptable->setColumnCount(5);
	QStringList list;
	list << tr("Name") << tr("IP") << tr("MAC") << tr("Department") << tr("Additional");
	ptable->setHorizontalHeaderLabels(list);
}

void c_view::slot_save()
{
	QFileDialog fileDialog(this, tr("Save table as HTML"));
    QString file_name;
    fileDialog.setDefaultSuffix("html");
    fileDialog.setAcceptMode(QFileDialog::AcceptSave);
    fileDialog.setConfirmOverwrite(true);
    fileDialog.setDirectory(".");
    fileDialog.setFileMode(QFileDialog::AnyFile);
    fileDialog.setFilter("html-files *.html");
    if(fileDialog.exec())
    {
        file_name=fileDialog.selectedFiles().at(0);
        if(file_name!="")
        {
			QFile file(file_name);
			if(file.open(QIODevice::WriteOnly))
			{
				QTextStream stream(&file);
				stream << "<html> \n <head><title>Lan painter</title></head> \n <body> \n <table> \n";
				stream << "<tr><td>" << tr("N") << "</td><td>" << tr("Name") << "</td><td>" << tr("IP") << "</td><td>" << tr("MAC") << "</td><td>" << tr("Department") << "</td><td>" << tr("Additional") << "</td></tr> \n"; 
				if(counter>0)
				for(int i=0; i<counter; i++)
				{
					stream << "<tr><td>"+QString::number(i+1)+"</td>";
					for(int j=0; j<5; j++)
					stream << "<td>" << ptable->takeItem(i,j)->text() << "</td>";
					stream << "</tr> \n";	
				}
				stream << "</table></body></html>";	
			}
			file.close();
		}
    }	
}
